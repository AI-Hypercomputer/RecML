"""JAX TPU Embedding versioning utilities

For releases, the version is of the form:
  xx.yy.zz

For nightly builds, the date of the build is added:
  xx.yy.zz-devYYYMMDD
"""

_base_version = "0.1.0"
_version_suffix = "dev20260226"

# Git commit corresponding to the build, if available.
__git_commit__ = "4d6a2e548c7f4a34c0755bc7185c6c0c765b173b"

# Library version.
__version__ = _base_version + _version_suffix

